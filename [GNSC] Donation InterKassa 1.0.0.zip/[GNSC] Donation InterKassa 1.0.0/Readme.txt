[GNSC] Donation Interkassa

INSTALLATION:
- Upload contents of Upload folder to root directory, overwriting any existing files.
- Install XML\addon-Donation_InterKassa-1.0.0 file.
- To set options go to: Admin > Options > [GNSC] Donation InterKassa


https://www.interkassa.com/technical-integration/