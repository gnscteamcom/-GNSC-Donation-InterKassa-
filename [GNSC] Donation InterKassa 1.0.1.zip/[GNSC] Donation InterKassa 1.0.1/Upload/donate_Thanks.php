﻿<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>THANKS FOR THE SUPPORT</title>
</head>

<body>
<p align="center"><font color="#000080">
<b><font size="5">THANKS FOR THE SUPPORT !</font></b><font size="5"> </font>
</font></p>
<p align="center"><font size="5" color="#000080"><a href="https://nulledcom.xyz">Payment
completed successfully, go to the website:<span lang="en-us">GNSC Team !</span></a></font></p>
</body>

</html>