<?php
/**
 * Created by GNSC Team
 * User: Suki Alamsyah
 * Date: 01.08.2016
 * Time: 12.00
 */

$XF_ROOT1=$_SERVER['DOCUMENT_ROOT'];

//There will generit Interkassa form of payments:

$fileDir = dirname(__FILE__);
require($fileDir . '/library/XenForo/Autoloader.php');
XenForo_Autoloader::getInstance()->setupAutoloader($fileDir . '/library');
XenForo_Application::initialize($fileDir . '/library', $fileDir);

$options = XenForo_Application::get('options'); //We get the list of options

$ID_Interkassa=$options->InterkassaId; //Get the settings from the ID box office
$Key_Interkassa=$options->InterkassaSecretKey; //We get the settings from a secret key offices
$Form_Interkassa=$options->InterKassaCheckoutName; //Get the name of the setting of payment.
$Cur_Interkassa=$options->InterkassaCur; //to choose the appropriate currency of your country. while supporting the USD, EUR, RUB, UAH

$IdPl=mt_rand (5, 800); //Get the ID of payment ... Just a random number!

//Make a check for a fool:*******************************************************************************************

if (isset($_POST['mytext']))
{
    $Pay_InterkassaGet=$_POST['mytext']; //Get how much to pay out of shape Donate ...
	
	$Pay_Interkassa=filter_var($Pay_InterkassaGet,FILTER_SANITIZE_NUMBER_FLOAT);
}
else
{
    echo 'Dont Worked ! :)';
    exit();
};

//**********************************************************************************************************************

//To generate a digital signature to form the beginning of a string, the algorithm Interkassa protocol: Price + ID + USD + 'payment Description' + 'Payment number' + 'secret key'

$SignatureISTR=$Pay_Interkassa.':'.$ID_Interkassa.':'.$Cur_Interkassa.':'.$Form_Interkassa.':'.$IdPl.':'.$Key_Interkassa;

$SignatureHash=base64_encode(hash('sha256', $SignatureISTR, true)); //Generates a digital signature of payment ...

//Generates a payment page:

$toreturn ='<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Confirmation of payment!</title>
</head>

<body>

 <form id="payment" name="payment" method="post" action="https://sci.interkassa.com/" enctype="utf-8">
	<input type="hidden" name="ik_co_id" value="'.$ID_Interkassa.'" />
	<input type="hidden" name="ik_pm_no" value= "'.$IdPl.'" />
	<input type="hidden" name="ik_am" value="'.$Pay_Interkassa.'" />
	<input type="hidden" name="ik_cur" value="'.$Cur_Interkassa.'" />
	<input type="hidden" name="ik_desc" value="'.$Form_Interkassa.'" />
	<input type="hidden" name="ik_sign" value="'.$SignatureHash.'">

	<p align="center"><span lang="en"><font size="3"><b>Confirmation of payment:</b></font></span></p>

<table border="1" align="center">
<tr>
<td>
<font size="3">Amount of payment:</font>
</td>
<td>
<font size="3">'.$Pay_Interkassa.':'.$Cur_Interkassa.'</font>
</td>
</tr>

<tr>
<td>
<font size="3">Purpose of payment:</font>
</td>
<td>
<font size="3">'.$Form_Interkassa.'</font>
</td>
</tr>

<tr>
<td>
<font size="3">Explanation:</font>
</td>
<td>
<font size="3">After clicking on "Pay!" Button, you can pay by any convenient way!</font>
</td>
</tr>

 </table>
 
 <style type="text/css">
  .cursor {cursor: pointer;} 
</style>


<p align="center"> 
<font size="4">
<input type="submit" value="PAY !" class="cursor"></font> </span>
</p>

</body>

</html>
';

echo $toreturn; //Withdraw our payment page ...

?>


